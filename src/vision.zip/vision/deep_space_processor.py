import math
import time

import numpy as np
import cv2

from .processor import Processor
from .network_tables_utils import *
from .contour_tools import *
from .math_utils import *


__all__ = ['DeepSpaceTargetProcessor']


class DeepSpaceTargetProcessor(Processor):
    """Run vision processing for FRC deep space vision.

    Notice that half the variables in the class are defined at the class
    level, instead of in the __init__ function which would place them at the
    instance level. This is because they're a special type of class called
    a descriptor. They function identically to normal class variables.

    I've set it up like this to make using them as simple as possible. Once
    they're defined, you can treat SyncedValues as normal
    variables, and everything else will go on behind the scenes.

    The PARENT_KEY variable represents the root SmartDashboard folder the
    variables should sync to, set it to '' to just sync to SmartDashboard. The
    syntax for creating a SyncedValue is
    SyncedValue(smart_dashboard_key, [default_value]). If default_value is
    omitted, then it will just pull from SmartDashboard.
    """

    PARENT_KEY = 'Vision Target/'

    # Debug values
    view_thresh = SyncedValue(f'{PARENT_KEY}Debug/view_thresh', False)
    view_modified = SyncedValue(f'{PARENT_KEY}Debug/view_modified', False)
    instant_fps = SyncedValue(f'{PARENT_KEY}Debug/fps', 0)
    average_fps = SyncedValue(f'{PARENT_KEY}Debug/average_fps', 0)
    timestamp = SyncedValue(f'{PARENT_KEY}Debug/timestamp', 0)

    # Camera offsets for tuning. Needed when the camera is not mounted perfectly
    x_camera_offset = SyncedValue(f'{PARENT_KEY}Camera Offset/x', 0)
    y_camera_offset = SyncedValue(f'{PARENT_KEY}Camera Offset/y', 0)
    z_camera_offset = SyncedValue(f'{PARENT_KEY}Camera Offset/z', 0)
    horizontal_camera_offset = SyncedValue(f'{PARENT_KEY}Camera Offset/horizontal_angle', 0)
    vertical_camera_offset = SyncedValue(f'{PARENT_KEY}Camera Offset/vertical_angle', 0)

    # Threshold values
    lower_hue = SyncedValue(f'{PARENT_KEY}Threshold/Lower/hue', 0)
    lower_sat = SyncedValue(f'{PARENT_KEY}Threshold/Lower/sat', 0)
    lower_val = SyncedValue(f'{PARENT_KEY}Threshold/Lower/val', 0)
    upper_hue = SyncedValue(f'{PARENT_KEY}Threshold/Upper/hue', 255)
    upper_sat = SyncedValue(f'{PARENT_KEY}Threshold/Upper/sat', 255)
    upper_val = SyncedValue(f'{PARENT_KEY}Threshold/Upper/val', 255)

    # Other values
    min_solidity = SyncedValue(f'{PARENT_KEY}min_solidity', 0.5)

    # Output values
    output_success = SyncedValue(f'{PARENT_KEY}Output/success', False)
    output_distance = SyncedValue(f'{PARENT_KEY}Output/distance', 0)
    output_horizontal_angle = SyncedValue(f'{PARENT_KEY}Output/horizontal_angle', 0)
    output_alignment_angle = SyncedValue(f'{PARENT_KEY}Output/alignment_angle', 0)
    output_vertical_angle = SyncedValue(f'{PARENT_KEY}Output/vertical_angle', 0)

    # Filters
    distance = MedianFilter(10)
    alignment_angle = MedianFilter(10)
    fps_filter = MovingAverage(15)

    # Constants
    OUTER_OBJECT_POINTS = np.array([
        [-19.6, 0, 0],
        [-9.8, -17, 0],
        [9.8, -17, 0],
        [19.6, 0, 0],
    ])
    INNER_OBJECT_POINTS = np.array([
        [-19.6, 0, 29.25],
        [-9.8, -17, 29.25],
        [9.8, -17, 29.25],
        [19.6, 0, 29.25],
    ])

    def __init__(self, size):
        self.size = size
        self.center = (
            size[0] // 2,
            size[1] // 2,
        )

        # Estimate the values of the camera and distortion matrices
        focal_length = size[0]
        self.camera_matrix = np.array([
            [focal_length, 0, self.center[0]],
            [0, focal_length, self.center[1]],
            [0, 0, 1]
        ], dtype='double')
        self.dist_matrix = np.zeros((4, 1))

    def process_image(self, image):
        start_time = time.time()

        thresh = self._threshold(image)
        _, contours, _ = cv2.findContours(
            thresh,
            cv2.RETR_LIST,
            cv2.CHAIN_APPROX_SIMPLE,
        )

        contours = self._get_valid_contours(contours)
        contours = sorted(
            contours,
            key=lambda c: cv2.contourArea(c),
            reverse=True,
        )

        self.output_success = len(contours) > 0
        if self.output_success:
            contour = contours[0]
            hull = cv2.convexHull(contour)

            points = np.array([
                hull[3][0],
                hull[2][0],
                hull[1][0],
                hull[0][0],
            ], dtype='float')

            _, rvec, tvec = cv2.solvePnP(
                self.OUTER_OBJECT_POINTS,
                points,
                self.camera_matrix,
                self.dist_matrix,
            )

            tvec[2][0] += self.z_camera_offset
            tvec[1][0] += self.y_camera_offset
            tvec[0][0] += self.x_camera_offset

            distance, horizontal_angle, vertical_angle, alignment_angle = self._process_vecs(tvec, rvec)
            self.distance.calculate(distance)
            self.alignment_angle.calculate(alignment_angle)
            horizontal_angle += self.horizontal_camera_offset
            vertical_angle += self.vertical_camera_offset

            if self.view_modified:
                # Outline contour
                cv2.drawContours(image, [contour], 0, self.BLUE, 2)
                # Draw contour middle
                mid = (
                    (hull[0][0][0] + hull[3][0][0]) // 2,
                    (hull[0][0][1] + hull[3][0][1]) // 2,
                )
                cv2.circle(image, mid, 3, self.RED, -1)
                cv2.circle(image, mid, 10, self.RED, 1)
                # Outline convex hull
                cv2.drawContours(image, [hull], 0, self.RED, 1)
                # Draw convex hull vertices
                for point in hull:
                    center = point[0][0], point[0][1]
                    cv2.circle(image, center, 6, self.WHITE, -1)
                # Add calculated values to screen
                self.left_label(image, [
                    f'Distance: {self.distance:.0f}',
                    f'Horizontal: {horizontal_angle:.0f}',
                    f'Vertical: {vertical_angle:.0f}',
                    f'Alignment: {self.alignment_angle:.0f}',
                ])

            self.output_distance = self.distance
            self.output_horizontal_angle = horizontal_angle
            self.output_vertical_angle = vertical_angle
            self.output_alignment_angle = self.alignment_angle

        fps = 1 / (time.time() - start_time)
        self.instant_fps = round(fps)
        self.fps_filter.calculate(fps)
        self.average_fps = round(self.fps_filter.calculate())
        smart_dashboard().flush()

        if self.view_modified:
            # Draw crosshair
            cv2.line(
                image,
                (self.center[0], 0),
                (self.center[0], self.size[1]),
                self.YELLOW,
                1
            )
            cv2.line(
                image,
                (0, self.center[1]),
                (self.size[0], self.center[1]),
                self.YELLOW,
                1
            )

        return_image = image
        if self.view_thresh:
            return_image = thresh

        return return_image

    def _threshold(self, BGR_image):
        image = cv2.cvtColor(BGR_image, cv2.COLOR_BGR2HSV)
        return cv2.inRange(
            image,
            (self.lower_hue, self.lower_sat, self.lower_val),
            (self.upper_hue, self.upper_sat, self.upper_val),
        )

    def _get_valid_contours(self, contours):
        valid = []
        for contour in contours:
            if len(contour) <= 5 or cv2.contourArea(contour) < 100:
                continue

            if len(cv2.convexHull(contour)) != 4:
                continue

            if solidity_of(contour) < self.min_solidity:
                continue

            valid.append(contour)
        return valid

    def _process_vecs(self, tvec, rvec):
        """Take in the translation and rotation vectors returned by solvePnP and
        calculate usable values."""

        x = tvec[0][0]
        y = tvec[1][0]
        z = tvec[2][0]

        # Straight line distance to target in 3 dimensions.
        distance = math.sqrt(x**2 + y**2 + z**2)

        # Angle the turret needs to turn/raise to align with the target.
        horizontal_angle = math.degrees(math.atan2(x, z))
        vertical_angle = -math.degrees(math.atan2(y, z))

        # Angle of the robot from the targets perspective; if the robot
        # is aligned dead-on with the target or looking at it from an
        # angle.
        R, _ = cv2.Rodrigues(rvec)
        points_at_origin = np.matmul(-R.T, tvec)
        alignment_angle = math.degrees(math.atan2(
                points_at_origin[0][0],
                points_at_origin[2][0],
        ))

        return distance, horizontal_angle, vertical_angle, alignment_angle
