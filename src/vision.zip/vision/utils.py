"""Some simple and general utilities for the Pi."""


import os
import sys


__all__ = ['get_ip', 'get_python_version']


def get_ip():
    return os.popen('hostname -I').read()[:-1]


def get_python_version():
    version = sys.version_info
    return f'{version[0]}.{version[1]}.{version[2]}'
